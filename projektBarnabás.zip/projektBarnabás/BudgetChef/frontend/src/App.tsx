import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";

import MainComp from "./components/MainComp";
import RecipesComp from "./components/RecipesComp";
import SoupsComp from "./components/SoupsComp";
import DessertsComp from "./components/DessertsComp";
import FavoritesComp from "./components/FavoritesComp";
import ProfileComp from "./components/ProfileComp";
import LoginComp from "./components/LoginComp";
import RegistComp from "./components/RegistComp";
import AdminComp from "./components/AdminComp";
import MainLayout from "./layouts/MainLayout";

function App() {
  return (
    <>
      <Routes>
        <Route path="/login" element={<LoginComp />} />
          <Route path="/register" element={<RegistComp />} />
          <Route path="/admin" element={<AdminComp />} />
        <Route element = {<MainLayout/>}>
          <Route path="/" element={<MainComp/>} />
          <Route path="/recipes" element={<RecipesComp />} />
          <Route path="/soups" element={<SoupsComp />} />
          <Route path="/desserts" element={<DessertsComp />} />
          <Route path="/favorites" element={<FavoritesComp />} />
          <Route path="/profile" element={<ProfileComp />} />
        </Route>
      </Routes>
    </>
  );
}

export default App;
