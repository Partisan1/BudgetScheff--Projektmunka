import { useEffect, useState } from "react";
import { fetchMe } from "../lib/auth";

export default function MainComp() {
  const [me, setMe] = useState<any>(null);

  useEffect(() => {
    fetchMe()
      .then(setMe)
      .catch(() => setMe(null));
  }, []);

  return (
    <div>
      {me ? <div>Belépve: {me.email}</div> : <div>Nincs belépve</div>}
    </div>
  );
}