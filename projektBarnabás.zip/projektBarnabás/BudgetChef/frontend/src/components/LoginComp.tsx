import React, { useMemo, useState, type FormEvent } from "react";
import { Alert, Button, Card, Container, Form, Spinner, Row, Col } from "react-bootstrap";
import { useNavigate } from "react-router-dom";
import api from "../lib/app";
import logo from "../assets/budgetchef.png";
import "./LoginComp.css";

const LoginComp = () => {
  const navigate = useNavigate();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [showPw, setShowPw] = useState(false);
  const [loading, setLoading] = useState(false);
  const [socialLoading, setSocialLoading] = useState<"google" | "facebook" | null>(null);
  const [error, setError] = useState<string | null>(null);

  const apiBase = import.meta.env.VITE_API_URL ?? "http://localhost:3001/api";

  const canSubmit = useMemo(() => {
    return email.trim().length > 3 && password.trim().length > 3 && !loading && !socialLoading;
  }, [email, password, loading, socialLoading]);

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;

    setError(null);
    setLoading(true);

    try {
      const res = await api.post("/user/login", { email, password });
      localStorage.setItem("user", JSON.stringify(res.data));
      navigate("/");
    } catch (err: any) {
      const msg = err?.response?.data?.message ?? "Sikertelen bejelentkezés";
      setError(Array.isArray(msg) ? msg.join(", ") : msg);
    } finally {
      setLoading(false);
    }
  };

  const handleSocial = (provider: "google" | "facebook") => {
    setError(null);
    setSocialLoading(provider);
    window.location.href = `${apiBase}/auth/${provider}`;
  };

  return (
    <div className="login-page">
      <Container className="login-center">
        <Card className="login-card">
          <Card.Body>
            <div className="login-head">
              <div className="login-logo-wrap">
                <img src={logo} alt="BudgetChef logo" className="login-logo" />
              </div>

              <h1 className="login-title">Üdv újra a ReceptSarokban!</h1>
              <p className="login-subtitle">
                Spórolj időt és pénzt — gyors menütervezés, bevásárlólista, költségbarát receptek.
              </p>

              <div className="login-badges" aria-label="Bizalmi jelzések">
                <span className="badge-pill">🥗 Heti menüterv</span>
                <span className="badge-pill">🧾 Bevásárlólista</span>
                <span className="badge-pill">💸 Költségbarát</span>
              </div>
            </div>

            {error && (
              <Alert variant="danger" className="mb-3">
                {error}
              </Alert>
            )}

            <div className="login-social-stack">
              <Button
                type="button"
                className="login-social google"
                onClick={() => handleSocial("google")}
                disabled={loading || !!socialLoading}
              >
                <span className="icon g">G</span>
                {socialLoading === "google" ? "Átirányítás..." : "Folytatás Google-lel"}
              </Button>

              <Button
                type="button"
                className="login-social fb"
                onClick={() => handleSocial("facebook")}
                disabled={loading || !!socialLoading}
              >
                <span className="icon">f</span>
                {socialLoading === "facebook" ? "Átirányítás..." : "Folytatás Facebookkal"}
              </Button>
            </div>

            <div className="login-divider">
              <span>vagy emaillel</span>
            </div>

            <Form onSubmit={handleSubmit}>
              <Form.Group className="mb-2">
                <Form.Label className="login-label">Email cím</Form.Label>
                <Form.Control
                  className="login-input"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  autoComplete="email"
                  placeholder="pl. anna@email.com"
                  required
                />
              </Form.Group>

              <Form.Group className="mb-2">
                <Form.Label className="login-label">Jelszó</Form.Label>

                <div className="pw-wrap">
                  <Form.Control
                    className="login-input pw-input"
                    type={showPw ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    autoComplete="current-password"
                    placeholder="••••••••"
                    required
                  />
                  <button
                    type="button"
                    className="pw-toggle"
                    onClick={() => setShowPw((s) => !s)}
                    aria-label={showPw ? "Jelszó elrejtése" : "Jelszó megjelenítése"}
                  >
                    {showPw ? "🙈" : "👁️"}
                  </button>
                </div>

                <div className="login-underrow">
                  <Form.Check
                    type="checkbox"
                    id="rememberMe"
                    label="Emlékezz rám"
                    className="remember-me"
                  />
                  <a className="forgot-link" href="/forgot-password">
                    Elfelejtetted?
                  </a>
                </div>
              </Form.Group>

              <Button type="submit" className="login-btn" disabled={!canSubmit}>
                {loading ? (
                  <>
                    <Spinner size="sm" className="me-2" />
                    Beléptetés...
                  </>
                ) : (
                  "Belépek és folytatom"
                )}
              </Button>

              <Row className="mt-3 g-2">
                <Col xs={12}>
                  <Button
                    type="button"
                    className="register-cta"
                    onClick={() => navigate("/register")}
                    disabled={loading || !!socialLoading}
                  >
                    Ingyenes fiók létrehozása
                  </Button>
                </Col>
              </Row>

              <div className="login-footer">
                <span className="muted">
                  A belépéssel elfogadod az <a href="/terms">ÁSZF</a>-et és az <a href="/privacy">Adatkezelést</a>.
                </span>
              </div>
            </Form>
          </Card.Body>
        </Card>
      </Container>
    </div>
  );
};

export default LoginComp;
