import api from "./app";
export async function fetchMe() {
    const res = await api.get("/auth/me")
    return res.data
}