import { Body, Controller, Delete, Get, Param, ParseIntPipe, Post, UnauthorizedException} from '@nestjs/common';
import { UserService } from './user.service';
import { CreateUserDto, LoginDto} from './user.dto';

@Controller('user')
export class UserController {
    constructor(private readonly service: UserService){}

    @Get()
    async getAll(){
        return await this.service.findAllUser();
    }

    @Post('register')
    async postUser(@Body() dto: CreateUserDto){
        return await this.service.createUser(dto);
    }

    @Post('login')
    async loginedUser(@Body() dto: LoginDto){
        const user = await this.service.loginUser(dto.email, dto.password);
        if (!user) throw new UnauthorizedException('Invalid credentials');
        return user;
    }

    @Delete(':id')
    async deleteUser(@Param("id", ParseIntPipe) id: number){
        return await this.service.removeUser(id)
    }
}
