import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaClient } from '@prisma/client/extension';
import { CreateRecipeDto, UpdateRecipeDto } from './recipe.dto';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class RecipeService {
    constructor(private readonly prisma: PrismaService) {}

    async findAllRecipe(){
        return await this.prisma.recipe.findMany({select: {
            title:true,
            description: true,
            ingredients: true,
            steps: true,
            price: true,
            imageUrl: true,
            allergens: true,
            status: true
        }});
    }
    async getRecipeById(id:number){
        const exists = await this.prisma.recipe.findUnique({where: {id}});
        if(!exists) throw new NotFoundException("Recipe not found!");
        return await this.prisma.recipe.findUnique({where: {id}});
    }
    async createRecipe(newRecipe: CreateRecipeDto){
        return await this.prisma.recipe.create({
            data: {
              title: newRecipe.title,
              description: newRecipe.description,
              ingredients: newRecipe.ingredients,
              steps: newRecipe.steps,
              price: newRecipe.price,
              imageUrl: newRecipe.imageUrl,
              allergens: newRecipe.allergens,
              userId: newRecipe.userId,
              rating: newRecipe.rating
            },
          });
    }
    async updateRecipe(id: number, dto: UpdateRecipeDto) {
        const exists = await this.prisma.recipe.findUnique({ where: { id } });
        if (!exists) throw new NotFoundException('Recipe not found');
      
        return this.prisma.recipe.update({
          where: { id },
          data: {
            ...(dto.title && { title: dto.title }),
            ...(dto.description && { description: dto.description }),
            ...(dto.ingredients && { ingredients: dto.ingredients }),
            ...(dto.steps && { steps: dto.steps }),
            ...(dto.price !== undefined && { price: dto.price }),
            ...(dto.imageUrl && { imageUrl: dto.imageUrl }),
            ...(dto.allergens && { allergens: dto.allergens }),
            ...(dto.status && { status: dto.status }),
          },
        });
      }
      
    async deleteRecipe(id:number){
        const exists = await this.prisma.recipe.findUnique({where:{id}});
        if(!exists) throw new NotFoundException("Recipe not found!");
        return await this.prisma.recipe.delete({where: {id}});
    }
}
