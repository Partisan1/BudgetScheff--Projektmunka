import { Body, Controller, Delete, Get, Param, ParseIntPipe, Post, Put } from '@nestjs/common';
import { RecipeService } from './recipe.service';
import { CreateRecipeDto, UpdateRecipeDto } from './recipe.dto';

@Controller('recipes')
export class RecipeController {
    constructor(private readonly service: RecipeService){}

    @Get()
    async getRecipes(){
        return await this.service.findAllRecipe();
    }

    @Get(":id")
    async getRecipeById(@Param("id", ParseIntPipe)id: number){
        return await this.service.getRecipeById(id);
    }

    @Post()
    async postRecipe(@Body() dto: CreateRecipeDto){
        return await this.service.createRecipe(dto);
    }

    @Put(":id")
    async updateRecipe(@Param("id", ParseIntPipe,) id: number, @Body() dto: UpdateRecipeDto){
        return await this.service.updateRecipe(id, dto);
    }

    @Delete(":id")
    async removeRecipe(@Param("id", ParseIntPipe)id: number){
        return await this.service.deleteRecipe(id);
    }
}
