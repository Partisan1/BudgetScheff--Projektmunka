import { Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwt: JwtService,
  ) {}

  async upsertOAuthUser(data: { email?: string; name: string; provider: string; providerId: string }) {
    if (!data.email) {
      // FB-nél előfordulhat
      throw new UnauthorizedException('A szolgáltató nem adott vissza email címet.');
    }

    return this.prisma.user.upsert({
      where: { email: data.email },
      update: {
        username: data.name,
        provider: data.provider,
        providerId: data.providerId,
      },
      create: {
        username: data.name,
        email: data.email,
        favorites: '[]',   
        provider: data.provider,
        providerId: data.providerId,
      },
    });
  }

  signAccessToken(user: { id: number; email: string; isAdmin?: boolean }) {
    return this.jwt.sign({
      sub: user.id,
      email: user.email,
      isAdmin: user.isAdmin ?? false,
    });
  }
}