import { IsString, IsNumber, MinLength, MaxLength, IsOptional, } from "class-validator";

export enum RecipeStatus {
    PENDING = 'PENDING',
    APPROVED = 'APPROVED',
    REJECTED = 'REJECTED',
  }

export class CreateRecipeDto{
    @IsString()
    @MinLength(3)
    title!: string;

    @IsString()
    @MinLength(10)
    description!: string;

    @IsString()
    ingredients!: string;

    @IsString()
    steps!: string;

    @IsNumber()
    price!: number;

    @IsString()
    imageUrl!: string

    @IsString()
    allergens!: string;

    @IsNumber()
    rating!: number

    status!: RecipeStatus;

    @IsNumber()
    userId!: number
}

export class UpdateRecipeDto{
    @IsOptional()
    @IsString()
    @MinLength(3)
    title?: string;

    @IsOptional()
    @IsString()
    @MinLength(10)
    description?: string;

    @IsOptional()
    @IsString()
    ingredients?: string;

    @IsOptional()
    @IsString()
    steps?: string;

    @IsOptional()
    @IsNumber()
    price?: number;

    @IsOptional()
    imageUrl?: string

    @IsOptional()
    @IsString()
    allergens?: string;

    @IsOptional()
    status?: RecipeStatus;
}