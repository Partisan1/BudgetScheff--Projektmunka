import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaClient } from '@prisma/client/extension';
import { CreateRecipeDto, UpdateRecipeDto } from './recipe.dto';
import { PrismaService } from '../prisma/prisma.service';

@Injectable()
export class RecipeService {
    constructor(private readonly prisma: PrismaService) {}

    async findAllRecipe(){
        return await this.prisma.recipe.findMany({select: {
            title:true,
            description: true,
            ingredients: true,
            steps: true,
            price: true,
            imageUrl: true,
            allergens: true,
            status: true
        }});
    }
    async findPENDINGRecipes(){     // ADMIN JOG
      return await this.prisma.recipe.findMany({where: {status: 'PENDING'}});
    }

    async getRecipeById(id:number){
        const exists = await this.prisma.recipe.findUnique({where: {id}});
        if(!exists) throw new NotFoundException("Recipe not found!");
        return await this.prisma.recipe.findUnique({where: {id}});
    }
    async createRecipe(newRecipe: CreateRecipeDto){
        return await this.prisma.recipe.create({
            data: newRecipe,
          });
    }
    async updateRecipe(id: number, dto: UpdateRecipeDto) {
        const exists = await this.prisma.recipe.findUnique({ where: { id } });
        if (!exists) throw new NotFoundException('Recipe not found');
      
        return this.prisma.recipe.update({
          where: { id },
          data: dto
        });
      }
      
    async deleteRecipe(id:number){
        const exists = await this.prisma.recipe.findUnique({where:{id}});
        if(!exists) throw new NotFoundException("Recipe not found!");
        return await this.prisma.recipe.delete({where: {id}});
    }
}
