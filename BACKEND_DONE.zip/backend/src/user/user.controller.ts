import { Body, Controller, Delete, Get, Param, ParseIntPipe, Post, Put } from '@nestjs/common';
import { UserService } from './user.service';
import { CreateUserDto, UpdateUserDto } from './user.dto';

@Controller('user')
export class UserController {
    constructor(private readonly service: UserService){}

    @Get()
    async getAll(){
        return await this.service.findAllUser();
    }

    @Put('me')
    async update(@Body()dto: UpdateUserDto, @Param('id', ParseIntPipe) id: number){
        return await this.service.updateUser(dto, id);
    }

    @Delete(':id')
    async deleteUser(@Param("id", ParseIntPipe) id: number){
        return await this.service.removeUser(id)
    }
}
