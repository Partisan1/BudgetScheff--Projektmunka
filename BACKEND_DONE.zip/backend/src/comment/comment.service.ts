import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateCommentDto } from './comment.dto';
import { connect } from 'http2';

@Injectable()
export class CommentService {
    constructor(private readonly prisma: PrismaService){}

    async getCommentById(recipeId: number){
        const exists = await this.prisma.recipe.findUnique({where: {id: recipeId}});
        if(!exists) throw new NotFoundException('Recipe not found!');
        const recipe = await this.prisma.recipe.findUnique({where: {id: recipeId}, include:{ comments: true}});
        return recipe?.comments;
    }

    async postComment(recipeId: number, userId: number, content: string, rating: number){
        const exists = await this.prisma.recipe.findUnique({where: {id: recipeId}});
        if(!exists) throw new NotFoundException('Recipe not found!');
        return await this.prisma.comment.create({
        data:{
            content,
            rating,
            recipe: {connect: {id: recipeId}},
            user: {connect: {id: userId}}
        }});
    }

    async deleteComment(commentId: number){
        const exists = await this.prisma.comment.findUnique({where: {id: commentId}});
        if(!exists) throw new NotFoundException('Recipe not found!');
        return await this.prisma.comment.delete({where: {id: commentId}});
    }
}
