import { Injectable } from '@nestjs/common';
import { PrismaClient } from '@prisma/client/extension';
import { CreateUserDto } from './user.dto';
import { NotFoundError } from 'rxjs';

@Injectable()
export class UserService {
    constructor(private readonly prisma: PrismaClient){}

    async findAllUser(){
        return await this.prisma.user.findMany({select:{
            id: true,
            username: true,
            email: true,
            password: true,
            isAdmin: true
        }})
    }
    async createUser(newUser: CreateUserDto){
        const user = await this.prisma.user.create({data: {newUser}})
        return user;
    }
    async removeUser(id: number){
        const exists = await this.prisma.user.findUnique({where: {id}});
        if(!exists) throw new NotFoundError("User not found!");
        return await this.prisma.user.delete({where: {id}, select:{id:true}})
    }
}
