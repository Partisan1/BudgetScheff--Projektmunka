import { Body, Controller, Delete, Get, Param, ParseIntPipe, Post } from '@nestjs/common';
import { UserService } from './user.service';
import { CreateUserDto } from './user.dto';

@Controller('user')
export class UserController {
    constructor(private readonly service: UserService){}

    @Get()
    async getAll(){
        return await this.service.findAllUser();
    }

    @Post()
    async postUser(@Body() dto: CreateUserDto){
        return await this.service.createUser(dto);
    }

    @Delete(':id')
    async deleteUser(@Param("id", ParseIntPipe) id: number){
        return await this.service.removeUser(id)
    }
}
