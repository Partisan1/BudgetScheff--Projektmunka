import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaClient } from '@prisma/client/extension';
import { CreateRecipeDto, UpdateRecipeDto } from './recipe.dto';

@Injectable()
export class RecipeService {
    constructor(private readonly prisma: PrismaClient) {}

    async findAllRecipe(){
        return await this.prisma.recipe.findMany({select: {
            title:true,
            description: true,
            ingredients: true,
            steps: true,
            price: true,
            imageUrl: true,
            allergens: true,
            status: true
        }});
    }
    async getRecipeById(id:number){
        const exists = await this.prisma.recipe.findUnique({where: {id}});
        if(!exists) throw new NotFoundException("Recipe not found!");
        return await this.prisma.recipe.findUnique({where: {id}});
    }
    async createRecipe(newRecipe: CreateRecipeDto){
        return await this.prisma.create({data: {newRecipe}});
    }
    async updateRecipe(id:number, data: UpdateRecipeDto){
        const exists = await this.prisma.recipe.findUnique({where:{id}});
        if(!exists) throw new NotFoundException("Recipe not found!");
        return await this.prisma.recipe.update({where: {id}, data});
    }
    async deleteRecipe(id:number){
        const exists = await this.prisma.recipe.findUnique({where:{id}});
        if(!exists) throw new NotFoundException("Recipe not found!");
        return await this.prisma.recipe.delete({where: {id}});
    }
}
