import { ConflictException, Injectable } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import argon2 from 'argon2';
import { UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { LoginUserDto, RegisterUserDto } from './auth.dto';

@Injectable()
export class AuthService {
    constructor(
        private readonly jwtService: JwtService,
        private readonly prisma: PrismaService,
    ) {}

    async authRegister(user: RegisterUserDto) {
        const exists = await this.prisma.user.findUnique({where: {
            email: user.email
        }, select: { id: true}});

        if (exists) throw new ConflictException('Email already in use');

        const hashedPasswd = await argon2.hash(user.password);

        const registerUser = await this.prisma.user.create({
            data: {
                email: user.email,
                username: user.username,
                password: hashedPasswd,
                favorites: ""
            }, 
            select: {
                email: true,
                username: true,
            }
        })
    };

    async authLogin(user: LoginUserDto) {
        const loginUser = await this.prisma.user.findUnique({
            where: {email: user.email},
            select: {
                id: true,
                email: true,
                username: true,
                password: true,
            }
        });

        if (!loginUser) throw new UnauthorizedException('Hibás email vagy jelszó');
        const ok = await argon2.verify(loginUser.password, user.password);
        if (!ok) throw new UnauthorizedException('Hibás jelszó');
        const {password, ...logUser} = loginUser;

        const payload =  {
            sub: logUser.id,
            email: logUser.email,
        }

        return {user: logUser, accessToken: this.jwtService.sign(payload)}
    }
}
