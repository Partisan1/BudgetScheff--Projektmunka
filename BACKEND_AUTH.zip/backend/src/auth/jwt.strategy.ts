import { Injectable } from "@nestjs/common";
import { Strategy, ExtractJwt } from "passport-jwt";
import { PassportStrategy } from '@nestjs/passport';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy, 'jwt') {
    constructor() {
        super({
            jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(), // Kivesszük a tokent - nincs közvetlen sztring-művelet...
            ignoreExpiration: false, // Ne hagyja figyelmen kívül a lejárati időt!
            secretOrKey: process.env.JWT_SECRET || 'my-secret',  // secret_key-t vesszük ki a .env-ből.  ??? jwt.cofig???
        })
    }
    // Ha a token érvényes, akkor visszaadjuk a payload-ot, amit beleteszünk a request-be.
    async validate(payload: any) {
        return {
            id: payload.sub,
            email: payload.email,
            name: payload.name,
        }
    }
}