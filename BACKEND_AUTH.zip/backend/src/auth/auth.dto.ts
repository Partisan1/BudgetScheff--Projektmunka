import {IsString, IsEmail, IsNumber, MinLength} from 'class-validator';

export class RegisterUserDto {
    @IsString()
    username!: string;

    @IsEmail()
    email!: string;

    @IsString()
    password!:string;
}

export class LoginUserDto {
    @IsString()
    email!: string;
    
    @IsString()
    password!:string;
}