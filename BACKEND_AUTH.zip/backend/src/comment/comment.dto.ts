import { IsNumber, IsString } from "class-validator"


export class CreateCommentDto{
    @IsString()
    content!: string

    @IsNumber()
    rating!: number

    @IsNumber()
    userId!: number

    @IsNumber()
    recipeId!: number
}

/* export class DeleteCommentDto{
    @IsNumber()
    id!: number

    @IsString()
    content!: string

    @IsNumber()
    rating!: number

    @IsNumber()
    userId!: number

    @IsNumber()
    recipeId!: number
} */