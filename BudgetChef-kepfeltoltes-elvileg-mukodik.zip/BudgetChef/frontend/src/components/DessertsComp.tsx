import React from 'react'

const DessertsComp = () => {
  return (
    <div>DessertsComp</div>
  )
}

export default DessertsComp