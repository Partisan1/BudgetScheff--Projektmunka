import React from 'react'

const ProfileComp = () => {
  return (
    <div>ProfileComp</div>
  )
}

export default ProfileComp