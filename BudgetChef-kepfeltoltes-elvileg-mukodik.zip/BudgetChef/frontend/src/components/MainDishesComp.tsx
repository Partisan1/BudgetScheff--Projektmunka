import React from 'react'

const MainDishesComp = () => {
  return (
    <div>MainDishesComp</div>
  )
}

export default MainDishesComp