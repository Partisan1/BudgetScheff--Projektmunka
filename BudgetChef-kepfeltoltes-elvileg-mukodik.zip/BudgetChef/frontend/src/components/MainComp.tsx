import React from 'react'

const MainComp = () => {
  return (
    <div>MainComp</div>
  )
}

export default MainComp