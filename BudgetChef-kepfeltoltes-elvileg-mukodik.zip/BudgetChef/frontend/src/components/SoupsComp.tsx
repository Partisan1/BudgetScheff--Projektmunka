import React from 'react'

const SoupsComp = () => {
  return (
    <div>SoupsComp</div>
  )
}

export default SoupsComp