import React from 'react'

const RegistComp = () => {
  return (
    <div>RegistComp</div>
  )
}

export default RegistComp